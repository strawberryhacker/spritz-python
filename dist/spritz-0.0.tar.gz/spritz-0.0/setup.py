from setuptools import setup

setup(name = 'spritz', version = '0.0', description = 'spritz cipher implementation', packages = ['spritz'], zip_safe = False)